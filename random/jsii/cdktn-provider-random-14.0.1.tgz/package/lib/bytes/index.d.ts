/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BytesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Arbitrary map of values that, when changed, will trigger recreation of resource. See [the main provider documentation](../index.html) for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/bytes#keepers Bytes#keepers}
    */
    readonly keepers?: {
        [key: string]: string;
    };
    /**
    * The number of bytes requested. The minimum value for length is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/bytes#length Bytes#length}
    */
    readonly length: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/bytes random_bytes}
*/
export declare class Bytes extends cdktn.TerraformResource {
    static readonly tfResourceType = "random_bytes";
    /**
    * Generates CDKTN code for importing a Bytes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Bytes to import
    * @param importFromId The id of the existing Bytes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/bytes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Bytes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/bytes random_bytes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BytesConfig
    */
    constructor(scope: Construct, id: string, config: BytesConfig);
    get base64(): string;
    get hex(): string;
    private _keepers?;
    get keepers(): {
        [key: string]: string;
    };
    set keepers(value: {
        [key: string]: string;
    });
    resetKeepers(): void;
    get keepersInput(): {
        [key: string]: string;
    } | undefined;
    private _length?;
    get length(): number;
    set length(value: number);
    get lengthInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
