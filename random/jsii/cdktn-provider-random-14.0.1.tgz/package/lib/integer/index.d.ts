/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IntegerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Arbitrary map of values that, when changed, will trigger recreation of resource. See [the main provider documentation](../index.html) for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/integer#keepers Integer#keepers}
    */
    readonly keepers?: {
        [key: string]: string;
    };
    /**
    * The maximum inclusive value of the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/integer#max Integer#max}
    */
    readonly max: number;
    /**
    * The minimum inclusive value of the range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/integer#min Integer#min}
    */
    readonly min: number;
    /**
    * A custom seed to always produce the same value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/integer#seed Integer#seed}
    */
    readonly seed?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/integer random_integer}
*/
export declare class Integer extends cdktn.TerraformResource {
    static readonly tfResourceType = "random_integer";
    /**
    * Generates CDKTN code for importing a Integer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Integer to import
    * @param importFromId The id of the existing Integer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/integer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Integer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/random/3.8.1/docs/resources/integer random_integer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntegerConfig
    */
    constructor(scope: Construct, id: string, config: IntegerConfig);
    get id(): string;
    private _keepers?;
    get keepers(): {
        [key: string]: string;
    };
    set keepers(value: {
        [key: string]: string;
    });
    resetKeepers(): void;
    get keepersInput(): {
        [key: string]: string;
    } | undefined;
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
    get result(): number;
    private _seed?;
    get seed(): string;
    set seed(value: string);
    resetSeed(): void;
    get seedInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
