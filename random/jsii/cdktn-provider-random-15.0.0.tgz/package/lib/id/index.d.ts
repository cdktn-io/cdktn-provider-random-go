/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface IdConfig extends cdktn.TerraformMetaArguments {
    /**
    * The number of random bytes to produce. The minimum value is 1, which produces eight bits of randomness.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/id#byte_length Id#byte_length}
    */
    readonly byteLength: number;
    /**
    * Arbitrary map of values that, when changed, will trigger recreation of resource. See [the main provider documentation](../index.html) for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/id#keepers Id#keepers}
    */
    readonly keepers?: {
        [key: string]: string;
    };
    /**
    * Arbitrary string to prefix the output value with. This string is supplied as-is, meaning it is not guaranteed to be URL-safe or base64 encoded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/id#prefix Id#prefix}
    */
    readonly prefix?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/id random_id}
*/
export declare class Id extends cdktn.TerraformResource {
    static readonly tfResourceType = "random_id";
    /**
    * Generates CDKTN code for importing a Id resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Id to import
    * @param importFromId The id of the existing Id that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Id to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/id random_id} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IdConfig
    */
    constructor(scope: Construct, id: string, config: IdConfig);
    get b64Std(): string;
    get b64Url(): string;
    private _byteLength?;
    get byteLength(): number;
    set byteLength(value: number);
    get byteLengthInput(): number | undefined;
    get dec(): string;
    get hex(): string;
    get id(): string;
    private _keepers?;
    get keepers(): {
        [key: string]: string;
    };
    set keepers(value: {
        [key: string]: string;
    });
    resetKeepers(): void;
    get keepersInput(): {
        [key: string]: string;
    } | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
