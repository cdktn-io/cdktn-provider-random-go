/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ShuffleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The list of strings to shuffle.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/shuffle#input Shuffle#input}
    */
    readonly input: string[];
    /**
    * Arbitrary map of values that, when changed, will trigger recreation of resource. See [the main provider documentation](../index.html) for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/shuffle#keepers Shuffle#keepers}
    */
    readonly keepers?: {
        [key: string]: string;
    };
    /**
    * The number of results to return. Defaults to the number of items in the `input` list. If fewer items are requested, some elements will be excluded from the result. If more items are requested, items will be repeated in the result but not more frequently than the number of items in the input list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/shuffle#result_count Shuffle#result_count}
    */
    readonly resultCount?: number;
    /**
    * Arbitrary string with which to seed the random number generator, in order to produce less-volatile permutations of the list.
    *
    * **Important:** Even with an identical seed, it is not guaranteed that the same permutation will be produced across different versions of Terraform. This argument causes the result to be *less volatile*, but not fixed for all time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/shuffle#seed Shuffle#seed}
    */
    readonly seed?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/shuffle random_shuffle}
*/
export declare class Shuffle extends cdktn.TerraformResource {
    static readonly tfResourceType = "random_shuffle";
    /**
    * Generates CDKTN code for importing a Shuffle resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Shuffle to import
    * @param importFromId The id of the existing Shuffle that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/shuffle#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Shuffle to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/shuffle random_shuffle} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ShuffleConfig
    */
    constructor(scope: Construct, id: string, config: ShuffleConfig);
    get id(): string;
    private _input?;
    get input(): string[];
    set input(value: string[]);
    get inputInput(): string[] | undefined;
    private _keepers?;
    get keepers(): {
        [key: string]: string;
    };
    set keepers(value: {
        [key: string]: string;
    });
    resetKeepers(): void;
    get keepersInput(): {
        [key: string]: string;
    } | undefined;
    get result(): string[];
    private _resultCount?;
    get resultCount(): number;
    set resultCount(value: number);
    resetResultCount(): void;
    get resultCountInput(): number | undefined;
    private _seed?;
    get seed(): string;
    set seed(value: string);
    resetSeed(): void;
    get seedInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
