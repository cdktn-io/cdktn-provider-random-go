/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PasswordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Arbitrary map of values that, when changed, will trigger recreation of resource. See [the main provider documentation](../index.html) for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#keepers Password#keepers}
    */
    readonly keepers?: {
        [key: string]: string;
    };
    /**
    * The length of the string desired. The minimum value for length is 1 and, length must also be >= (`min_upper` + `min_lower` + `min_numeric` + `min_special`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#length Password#length}
    */
    readonly length: number;
    /**
    * Include lowercase alphabet characters in the result. Default value is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#lower Password#lower}
    */
    readonly lower?: boolean | cdktn.IResolvable;
    /**
    * Minimum number of lowercase alphabet characters in the result. Default value is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#min_lower Password#min_lower}
    */
    readonly minLower?: number;
    /**
    * Minimum number of numeric characters in the result. Default value is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#min_numeric Password#min_numeric}
    */
    readonly minNumeric?: number;
    /**
    * Minimum number of special characters in the result. Default value is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#min_special Password#min_special}
    */
    readonly minSpecial?: number;
    /**
    * Minimum number of uppercase alphabet characters in the result. Default value is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#min_upper Password#min_upper}
    */
    readonly minUpper?: number;
    /**
    * Include numeric characters in the result. Default value is `true`. If `number`, `upper`, `lower`, and `special` are all configured, at least one of them must be set to `true`. **NOTE**: This is deprecated, use `numeric` instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#number Password#number}
    */
    readonly number?: boolean | cdktn.IResolvable;
    /**
    * Include numeric characters in the result. Default value is `true`. If `numeric`, `upper`, `lower`, and `special` are all configured, at least one of them must be set to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#numeric Password#numeric}
    */
    readonly numeric?: boolean | cdktn.IResolvable;
    /**
    * Supply your own list of special characters to use for string generation.  This overrides the default character list in the special argument.  The `special` argument must still be set to true for any overwritten characters to be used in generation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#override_special Password#override_special}
    */
    readonly overrideSpecial?: string;
    /**
    * Include special characters in the result. These are `!@#$%&*()-_=+[]{}<>:?`. Default value is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#special Password#special}
    */
    readonly special?: boolean | cdktn.IResolvable;
    /**
    * Include uppercase alphabet characters in the result. Default value is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#upper Password#upper}
    */
    readonly upper?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password random_password}
*/
export declare class Password extends cdktn.TerraformResource {
    static readonly tfResourceType = "random_password";
    /**
    * Generates CDKTN code for importing a Password resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Password to import
    * @param importFromId The id of the existing Password that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Password to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/resources/password random_password} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PasswordConfig
    */
    constructor(scope: Construct, id: string, config: PasswordConfig);
    get bcryptHash(): string;
    get id(): string;
    private _keepers?;
    get keepers(): {
        [key: string]: string;
    };
    set keepers(value: {
        [key: string]: string;
    });
    resetKeepers(): void;
    get keepersInput(): {
        [key: string]: string;
    } | undefined;
    private _length?;
    get length(): number;
    set length(value: number);
    get lengthInput(): number | undefined;
    private _lower?;
    get lower(): boolean | cdktn.IResolvable;
    set lower(value: boolean | cdktn.IResolvable);
    resetLower(): void;
    get lowerInput(): boolean | cdktn.IResolvable | undefined;
    private _minLower?;
    get minLower(): number;
    set minLower(value: number);
    resetMinLower(): void;
    get minLowerInput(): number | undefined;
    private _minNumeric?;
    get minNumeric(): number;
    set minNumeric(value: number);
    resetMinNumeric(): void;
    get minNumericInput(): number | undefined;
    private _minSpecial?;
    get minSpecial(): number;
    set minSpecial(value: number);
    resetMinSpecial(): void;
    get minSpecialInput(): number | undefined;
    private _minUpper?;
    get minUpper(): number;
    set minUpper(value: number);
    resetMinUpper(): void;
    get minUpperInput(): number | undefined;
    private _number?;
    get number(): boolean | cdktn.IResolvable;
    set number(value: boolean | cdktn.IResolvable);
    resetNumber(): void;
    get numberInput(): boolean | cdktn.IResolvable | undefined;
    private _numeric?;
    get numeric(): boolean | cdktn.IResolvable;
    set numeric(value: boolean | cdktn.IResolvable);
    resetNumeric(): void;
    get numericInput(): boolean | cdktn.IResolvable | undefined;
    private _overrideSpecial?;
    get overrideSpecial(): string;
    set overrideSpecial(value: string);
    resetOverrideSpecial(): void;
    get overrideSpecialInput(): string | undefined;
    get result(): string;
    private _special?;
    get special(): boolean | cdktn.IResolvable;
    set special(value: boolean | cdktn.IResolvable);
    resetSpecial(): void;
    get specialInput(): boolean | cdktn.IResolvable | undefined;
    private _upper?;
    get upper(): boolean | cdktn.IResolvable;
    set upper(value: boolean | cdktn.IResolvable);
    resetUpper(): void;
    get upperInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
