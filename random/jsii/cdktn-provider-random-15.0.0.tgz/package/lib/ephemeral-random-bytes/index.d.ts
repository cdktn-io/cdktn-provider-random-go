/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralRandomBytesConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * The number of bytes requested. The minimum value for length is 1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/bytes#length EphemeralRandomBytes#length}
    */
    readonly length: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/bytes random_bytes}
*/
export declare class EphemeralRandomBytes extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "random_bytes";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/bytes random_bytes} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralRandomBytesConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralRandomBytesConfig);
    get base64(): string;
    get hex(): string;
    private _length?;
    get length(): number;
    set length(value: number);
    get lengthInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
