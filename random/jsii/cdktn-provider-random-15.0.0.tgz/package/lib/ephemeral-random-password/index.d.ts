/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralRandomPasswordConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * The length of the string desired. The minimum value for length is 1 and, length must also be >= (`min_upper` + `min_lower` + `min_numeric` + `min_special`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#length EphemeralRandomPassword#length}
    */
    readonly length: number;
    /**
    * Include lowercase alphabet characters in the result. Default value is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#lower EphemeralRandomPassword#lower}
    */
    readonly lower?: boolean | cdktn.IResolvable;
    /**
    * Minimum number of lowercase alphabet characters in the result. Default value is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#min_lower EphemeralRandomPassword#min_lower}
    */
    readonly minLower?: number;
    /**
    * Minimum number of numeric characters in the result. Default value is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#min_numeric EphemeralRandomPassword#min_numeric}
    */
    readonly minNumeric?: number;
    /**
    * Minimum number of special characters in the result. Default value is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#min_special EphemeralRandomPassword#min_special}
    */
    readonly minSpecial?: number;
    /**
    * Minimum number of uppercase alphabet characters in the result. Default value is `0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#min_upper EphemeralRandomPassword#min_upper}
    */
    readonly minUpper?: number;
    /**
    * Include numeric characters in the result. Default value is `true`. If `numeric`, `upper`, `lower`, and `special` are all configured, at least one of them must be set to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#numeric EphemeralRandomPassword#numeric}
    */
    readonly numeric?: boolean | cdktn.IResolvable;
    /**
    * Supply your own list of special characters to use for string generation.  This overrides the default character list in the special argument.  The `special` argument must still be set to true for any overwritten characters to be used in generation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#override_special EphemeralRandomPassword#override_special}
    */
    readonly overrideSpecial?: string;
    /**
    * Include special characters in the result. These are `!@#$%&*()-_=+[]{}<>:?`. Default value is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#special EphemeralRandomPassword#special}
    */
    readonly special?: boolean | cdktn.IResolvable;
    /**
    * Include uppercase alphabet characters in the result. Default value is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password#upper EphemeralRandomPassword#upper}
    */
    readonly upper?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password random_password}
*/
export declare class EphemeralRandomPassword extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "random_password";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/random/3.9.0/docs/ephemeral-resources/password random_password} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralRandomPasswordConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralRandomPasswordConfig);
    get bcryptHash(): string;
    private _length?;
    get length(): number;
    set length(value: number);
    get lengthInput(): number | undefined;
    private _lower?;
    get lower(): boolean | cdktn.IResolvable;
    set lower(value: boolean | cdktn.IResolvable);
    resetLower(): void;
    get lowerInput(): boolean | cdktn.IResolvable | undefined;
    private _minLower?;
    get minLower(): number;
    set minLower(value: number);
    resetMinLower(): void;
    get minLowerInput(): number | undefined;
    private _minNumeric?;
    get minNumeric(): number;
    set minNumeric(value: number);
    resetMinNumeric(): void;
    get minNumericInput(): number | undefined;
    private _minSpecial?;
    get minSpecial(): number;
    set minSpecial(value: number);
    resetMinSpecial(): void;
    get minSpecialInput(): number | undefined;
    private _minUpper?;
    get minUpper(): number;
    set minUpper(value: number);
    resetMinUpper(): void;
    get minUpperInput(): number | undefined;
    private _numeric?;
    get numeric(): boolean | cdktn.IResolvable;
    set numeric(value: boolean | cdktn.IResolvable);
    resetNumeric(): void;
    get numericInput(): boolean | cdktn.IResolvable | undefined;
    private _overrideSpecial?;
    get overrideSpecial(): string;
    set overrideSpecial(value: string);
    resetOverrideSpecial(): void;
    get overrideSpecialInput(): string | undefined;
    get result(): string;
    private _special?;
    get special(): boolean | cdktn.IResolvable;
    set special(value: boolean | cdktn.IResolvable);
    resetSpecial(): void;
    get specialInput(): boolean | cdktn.IResolvable | undefined;
    private _upper?;
    get upper(): boolean | cdktn.IResolvable;
    set upper(value: boolean | cdktn.IResolvable);
    resetUpper(): void;
    get upperInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
